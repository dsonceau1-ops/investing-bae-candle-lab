# Investing Bae Candle & Price Action Mastery Lab — PWA

This folder contains the installable Progressive Web App version of the Candle & Price Action Mastery Lab.

## Files

- `index.html` — the full student training app
- `manifest.json` — app install metadata
- `service-worker.js` — offline caching
- `icons/` — app icons for mobile/desktop install

## How to test locally

Because service workers require a web server, open this folder with a local server instead of double-clicking the HTML file.

### Option A: Python

```bash
cd investing_bae_pwa
python3 -m http.server 8080
```

Then open `http://localhost:8080`.

### Option B: VS Code

Use the “Live Server” extension and open the folder.

## How to deploy fast

### Netlify

1. Go to Netlify.
2. Drag the entire `investing_bae_pwa` folder into the deploy area.
3. Open the provided URL.
4. On iPhone/Android, use “Add to Home Screen.”

### Vercel

1. Create a new project.
2. Upload/import this folder.
3. Deploy as a static site.

## Student install instructions

### iPhone / iPad

1. Open the site in Safari.
2. Tap Share.
3. Tap “Add to Home Screen.”
4. Open “Candle Lab” from the home screen.

### Android

1. Open the site in Chrome.
2. Tap the install prompt or the three-dot menu.
3. Tap “Install app” or “Add to Home screen.”

### Desktop Chrome / Edge

1. Open the site.
2. Click the install icon in the address bar.
3. Install “Candle Lab.”

## Notes

- Student progress is saved in the browser using local storage.
- Offline mode caches the app shell after the first visit.
- Video embeds require internet access.
